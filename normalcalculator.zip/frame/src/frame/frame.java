package frame;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class frame {

	public static void main(String[] args) {

		LinkedList<String> t = new LinkedList<String>();
		String str="0";
		JFrame jf=new JFrame("计算器");
		JTextField jtf=new JTextField("0",20);
		jf.add(jtf, BorderLayout.NORTH);
		String[] lab = {"CE","C","+/-","BackS","7","8","9","+","4","5","6",
				"-","1","2","3","*","0",".","=","/"}; //按键上的文本
		JPanel jp=new JPanel();
		GridLayout gl=new GridLayout(5,4);
		jp.setLayout(gl);

		JButton jb1=new JButton("CE");
		jp.add(jb1);
		JButton jb2=new JButton("C");
		jp.add(jb2);
		JButton jb3=new JButton("+/-");
		jp.add(jb3);
		jb1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				t.clear();

				jtf.setText(t.toString());

			}
		});
		jb2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){

				t.removeLast();
				jtf.setText(t.toString());
			}
		});
		jb3.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				t.add("+");

				jtf.setText(t.toString());
			}
		});
		JButton jb4=new JButton("BackS");
		jp.add(jb4);

		JButton jb5=new JButton("7");
		jp.add(jb5);
		JButton jb6=new JButton("8");
		jp.add(jb6);
		JButton jb7=new JButton("9");
		jp.add(jb7);
		jb5.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				t.add("7");
				jtf.setText(t.toString());
			}
		});

		jb4.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				t.removeLast();
				jtf.setText(t.toString());
			}
		});
		jb6.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				t.add("8");
				jtf.setText(t.toString());
			}
		});
		jb7.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				t.add("9");
				jtf.setText(t.toString());
			}
		});
		JButton jb8=new JButton("+");
		jp.add(jb8);
		JButton jb9=new JButton("4");
		jp.add(jb9);
		JButton jb10=new JButton("5");
		jp.add(jb10);
		JButton jb11=new JButton("6");
		jp.add(jb11);

		jb8.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				t.add("+");
				jtf.setText(t.toString());
			}
		});
		jb9.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				t.add("4");
				jtf.setText(t.toString());
			}
		});
		jb10.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				t.add("5");	
				jtf.setText(t.toString());
			}
		});
		jb11.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				t.add("6");
				jtf.setText(t.toString());
			}
		});
		JButton jb12=new JButton("-");
		jp.add(jb12);
		JButton jb13=new JButton("1");
		jp.add(jb13);
		JButton jb14=new JButton("2");
		jp.add(jb14);
		jb12.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				t.add("-");
				jtf.setText(t.toString());
			}
		});
		jb13.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				t.add("1");
				jtf.setText(t.toString());
			}
		});
		jb14.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				t.add("2");
				jtf.setText(t.toString());
			}
		});
		JButton jb15=new JButton("3");
		jp.add(jb15);
		JButton jb16=new JButton("*");
		jp.add(jb16);
		JButton jb17=new JButton("0");
		jp.add(jb17);
		JButton jb18=new JButton(".");
		jp.add(jb18);
		jb15.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				t.add("3");
				jtf.setText(t.toString());
			}
		});
		jb16.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				t.add("*");
				jtf.setText(t.toString());
			}
		});
		jb17.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				t.add("0");
				jtf.setText(t.toString());
			}
		});
		jb18.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				t.add(".");
				jtf.setText(t.toString());
			}
		});
		JButton jb19=new JButton("=");
		jp.add(jb19);
		JButton jb20=new JButton("/");
		jp.add(jb20);
		jb19.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				float num1=0;
				float num2=0;
				char ope;
				float result=0;
				num1=Integer.valueOf(t.pollFirst());
				do {
					while(t.get(0).toCharArray()[0]<='9' && t.get(0).toCharArray()[0]>='0') {

						num1=num1*10+Integer.valueOf(t.pollFirst());


					}	
					System.out.println(num1);
					ope=t.pollFirst().toCharArray()[0];
					System.out.println(ope);
					num2=Integer.valueOf(t.pollFirst());
					System.out.println(num2);


					while(!t.isEmpty() && t.get(0).toCharArray()[0]<='9' && t.get(0).toCharArray()[0]>='0') {

						num2=num2*10+Integer.valueOf(t.pollFirst());
						System.out.println("wozaizhe li aaaaa"+num2);

					}	

					if(!t.isEmpty() && t.get(0).toCharArray()[0]=='.') {     
						int i=0;
						t.pollFirst();
						while(!t.isEmpty() && t.get(0).toCharArray()[0]<='9' && t.get(0).toCharArray()[0]>='0') {

							i++;

							num2=(float) (num2+Integer.valueOf(t.pollFirst())/Math.pow(10,i )) ;

							System.out.println("wozaizhe li "+num2);
						}	



					}
					System.out.println(num2);
					switch(ope) {
					case '+': {
						result=num1+num2; 
						System.out.println(result);
						break;
					}
					case '-': {
						System.out.println(num2);
						result=num1-num2;  
						System.out.println(result);
						break;
					}
					case '*': {
						result=num1*num2;  
						System.out.println(result);
						break;
					}
					case '/': {
						result=num1/num2;  
						System.out.println(result);
						break;
					}

					case '.': {
						System.out.println("1:  "+result);
						int num3=0;
						num3=(int)num2;

						num2=Float.valueOf("0."+Integer.toString(num3));

						num1+=num2;

						result=num1;

						break;
					}

					}
					num1=result;

				}while(!t.isEmpty());
				jtf.setText(Float.toString(result));
			}});
		jb20.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				t.add("/");

				jtf.setText(t.toString());
			}
		});
		jf.add(jp);
		jf.pack();
		jf.setResizable(true);

		jf.setLocation(300,200); // 设置初始的位置
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//关闭





		jf.setVisible(true);


		/*
		 JFrame jf = new JFrame("计算器"); //创建一个窗口
	        JTextField jtf = new JTextField("0",20); //初始的文本为0，长度是20
	        jf.add(jtf,BorderLayout.NORTH); 
	        String[] lab = {"CE","C","+/-","BackS","7","8","9","+","4","5","6",
	            "-","1","2","3","*","0",".","=","/"}; //按键上的文本
	        JPanel jp = new JPanel(); //创建面板
	        GridLayout gl = new GridLayout(5,4); //创建网格布局
	        jp.setLayout(gl); //将面板的布局方式改为网格布局
	        for(int i=0;i<lab.length;i++){
	            JButton jb = new JButton(lab[i]); //创建按钮
	            jp.add(jb);//将创建出来的按钮都放入面板
	        }
	        jf.add(jp);//将面板放入窗口
	       jf.pack(); //自动调节大小
	        jf.setResizable(false);//不能改变窗口的大小
	        jf.setLocation(300,200); // 设置初始的位置
	        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//关闭
	        jf.setVisible(true); //解决了初始不可见的问题


		 */

		/*  JButton but1=new JButton("模态对话框");
	        JButton but2=new JButton("非模态对话框");
	        JFrame f=new JFrame("DialogDemo");
	        f.setSize(500, 400);
	        f.setLocation(300, 200);
	        f.setLayout(new FlowLayout());//设置布局管理器
	        f.add(but1);
	        f.add(but2);
	        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//设置默认关闭按钮
	        f.setVisible(true);

	        JLabel label=new JLabel();//创建一个标签

	        JDialog dialog=new JDialog(f,"Dialog");
	        dialog.setSize(220,150);
	        dialog.setLocation(400, 300);
	        dialog.setLayout(new FlowLayout());
	        final JButton but3=new JButton("确认");
	        dialog.add(but3);

	        //为模态对话框添加点击事件
	        but1.addActionListener(
	        		new ActionListener()
	        {
	        	public void actionPerformed(ActionEvent e){
	        		dialog.setModal(true);//设置对话框为模态
	        		if(dialog.getComponents().length==1){//若对话框中还没有添加标签则添加上
	        			dialog.add(label);
	        		}
	        		label.setText("模式对话窗，点击确认关闭");//修改标签内容
	        		dialog.setVisible(true);
	        	}
	        });

	        but2.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent e){
	        		dialog.setModal(false);//设置对话框为模态
	        		if(dialog.getComponents().length==1){//若对话框中还没有添加标签则添加上
	        			dialog.add(label);
	        		}
	        		label.setText("模式对话窗，点击确认关闭");//修改标签内容
	        		dialog.setVisible(true);
	        	}
	        });

	        but3.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					dialog.dispose();
				}
			});
		}
		 */
	}


}


